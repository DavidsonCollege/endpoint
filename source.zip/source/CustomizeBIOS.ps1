<#
.SYNOPSIS
    Combined script to configure Dell BIOS passwords and settings.

.DESCRIPTION
    This script combines the functionality of three separate scripts to:
    1. Verify if a standardized BIOS password is already in place
    2. Reset the BIOS password to a standardized value if needed
    3. Apply standard BIOS settings once password is configured

.PARAMETER Prepend
    The standard prefix part of the password that comes before the system-specific segment.
    
.PARAMETER Postpend
    The suffix part of the password that comes after the system-specific segment.

.PARAMETER GroupTag
    The group identifier used for tracking password reset status.

.PARAMETER TestMode
    Switch to enable test mode which provides additional logging of sensitive values.

.EXAMPLE
    .\CustomizeBIOS.ps1 -Prepend "Company" -GroupTag "Deployment2025"

.NOTES
    Created: March 12, 2025 - Merged from individual scripts originally created by Claude and abp
    Original scripts:
    - Main-CustomizeBIOS.ps1
    - BiosPwdResets.ps1
    - StandardBiosSettings.ps1
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Prepend,
    
    [Parameter(Mandatory=$true)]
    [string]$GroupTag,
    
    [Parameter(Mandatory=$false)]
    [string]$Postpend = "",
    
    [Switch]$TestMode
)

#region Setup and Logging Functions

# Set up logging
$logDir = "C:\ProgramData\Admin"
$logFile = Join-Path -Path $logDir -ChildPath "CustomizeBIOS.log"

# Create log directory if it doesn't exist
if (-not (Test-Path -Path $logDir -PathType Container)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

# Registry path for storing configuration status
$registryPath = "HKLM:\Software\Davidson"
if (!(Test-Path $registryPath)) {
    New-Item -Path $registryPath -Force | Out-Null
}

$warnCount = 0

# Unified log function
function Write-Log {
    param(
        [string]$Message,
        [string]$Type = "INFO",  # Default type is INFO
        [string]$Component = "Main"  # Default component is Main
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Type] [$Component] $Message"
    
    # Append to log file
    Add-Content -Path $logFile -Value $logMessage
    
    # Also output to console
    Write-Output $logMessage
}

#endregion

#region BIOS Settings Function

function Set-BiosSettings {
    param(
        [string]$AdminPassword
    )

    Write-Log "Starting BIOS Settings configuration" -Component "Settings"

    # Create directory if it doesn't exist
    $csvDirectory = "C:\ProgramData\admin"
    if (-not (Test-Path -Path $csvDirectory -PathType Container)) {
        New-Item -Path $csvDirectory -ItemType Directory -Force | Out-Null
    }

    # Define the settings we want to configure
    $settings = @(
        [PSCustomObject]@{
            Name = "EmbNic1"
            Value = "Enabled"
        },
        [PSCustomObject]@{
            Name = "UsbEmu"
            Value = "Disabled"
        },
        [PSCustomObject]@{
            Name = "PowerWarn"
            Value = "Enabled"
        },
        [PSCustomObject]@{
            Name = "HttpsBoot"
            Value = "Disabled"
        }
    )

    # Create an array to store the CSV filenames
    $csvFiles = @()

    # Loop through each setting and create a separate CSV file
    foreach ($setting in $settings) {
        # Create filename based on the setting name
        $fileName = "$($setting.Name).csv"
        $csvPath = Join-Path -Path $csvDirectory -ChildPath $fileName
        
        # Export single setting to its own CSV file
        Write-Log "Exporting CSV for $($setting.Name)" -Component "Settings"
        $setting | Export-Csv -Path $csvPath -NoTypeInformation
        
        # Remove quotes from the CSV file
        (Get-Content $csvPath) | ForEach-Object {$_ -Replace '"',""} | Out-File $csvPath -Force -Encoding ascii
        
        # Add the filename to our tracking array
        $csvFiles += $csvPath
    }

    # Path to the Dell BIOS script
    $dellScriptPath = Join-Path -Path $ScriptPath -ChildPath "Manage-DellBiosSettings-WMI.ps1"
    $dellLogPath = Join-Path -Path $logDir -ChildPath "Manage-DellBiosSettings-WMI.log"

    # Verify the script exists
    if (-not (Test-Path -Path $dellScriptPath)) {
        Write-Log "Could not find Manage-DellBiosSettings-WMI.ps1 at path: $dellScriptPath" -Type "ERROR" -Component "Settings"
        return 1
    }
    else { 
        Write-Log "Path ok $dellScriptPath" -Component "Settings"
    }

    # Process each CSV file
    foreach ($csvFile in $csvFiles) {
        $fileNameOnly = Split-Path -Path $csvFile -Leaf
        
        # Execute the Dell BIOS configuration script
        try {
            if ([string]::IsNullOrEmpty($AdminPassword)) {
                # Run without password
                & $dellScriptPath -SetSettings -CsvPath $csvFile -LogFile $dellLogPath
            } else {
                # Run with password
                & $dellScriptPath -SetSettings -CsvPath $csvFile -LogFile $dellLogPath -AdminPassword $AdminPassword
            }
			Write-Log "$fileNameOnly $LASTEXITCODE"
        } catch {
			Write-Log "Error configuring BIOS settings: $_" -Type "ERROR" -Component "Settings"
        }
		if ($LASTEXITCODE -eq 0) {
			Write-Log "$fileNameOnly successful"
		}
        elseif ($LASTEXITCODE -eq 3) {
            Write-Log "$fileNameOnly Setting not found error, continue" -Component "Settings"
            $csvData = Import-Csv -Path $csvFile
            $csvData | Add-Member -MemberType NoteProperty -Name "ProcessingNotFound" -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            $csvData | Export-Csv -Path $csvFile -NoTypeInformation
			$warnCount++
        }
        elseif ($LASTEXITCODE -eq 2) {
            Write-Log "$fileNameOnly Fatal error, quitting" -Type "ERROR" -Component "Settings"
            $csvData = Import-Csv -Path $csvFile
            $csvData | Add-Member -MemberType NoteProperty -Name "ProcessingFailed" -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            $csvData | Export-Csv -Path $csvFile -NoTypeInformation
			$warnCount++
        }
		else {
			Write-Log "Unknown error $LASTEXITCODE"
			$warnCount++
		}

        # Add timestamp to the csv for reference/troubleshooting
        $csvData = Import-Csv -Path $csvFile
        $csvData | Add-Member -MemberType NoteProperty -Name "ProcessedDate" -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        $csvData | Export-Csv -Path $csvFile -NoTypeInformation
    }

    Write-Log "BIOS Settings configuration complete" -Component "Settings"
	return $warnCount
}

#endregion

#region Main Execution

# Get script path
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Log "Script running from: $scriptPath"
Write-Log "Starting Dell BIOS Customization process"

# Step 1: Reset BIOS password if needed
Write-Log "Step 1: (Re)setting BIOS password to standardized value if needed"

$result = $null
$resetSuccess = $false
$errCode = $null
        
try {
    Write-Log "Running password check/reset"
	if ($TestMode) {
		Write-Log "Parameters: Prepend=$Prepend, Postpend=$Postpend, GroupTag=$GroupTag"
	}    
	
    if ([string]::IsNullOrWhiteSpace($Prepend) -and [string]::IsNullOrWhiteSpace($Postpend)) {
        Write-Log "At least one argument (Prepend or Postpend) must have a value" -Type "ERROR" -Component "PwdReset"
        return $null, 1
    }

    try {
        # Get computer's serial number
        $serialNumber = (Get-WmiObject -Class Win32_BIOS).SerialNumber
        Write-Log "Computer Serial Number: $serialNumber" -Component "PwdReset"

        # Define the path to the lookup CSV file
        $lookupFilePath = Join-Path $scriptPath "lookuplist.csv"
        Write-Log "Looking for CSV file at: $lookupFilePath" -Component "PwdReset"

        # Check if lookup file exists
        if (-not (Test-Path $lookupFilePath)) {
            Write-Log "Lookup file not found: $lookupFilePath" -Type "ERROR" -Component "PwdReset"
            throw "Lookup file not found: $lookupFilePath"
        }

        # Import CSV and find matching serial number
        $lookupData = Import-Csv $lookupFilePath
        Write-Log "Successfully imported CSV file" -Component "PwdReset"
        
        $matchingEntry = $lookupData | Where-Object { $_.Serial -eq $serialNumber }
        $CurrentPwd = $null

        if ($null -eq $matchingEntry) {
            Write-Log "No matching serial number found in lookup file" -Type "WARN" -Component "PwdReset"
        }
        else {
            $CurrentPwd = $matchingEntry.CurrentPwd
            Write-Log "Found current password for serial number $serialNumber computer $($matchingEntry.ComputerName)" -Component "PwdReset"
            if ($TestMode) { Write-Log $matchingEntry.CurrentPwd -Component "PwdReset" }
        }
        
        # Delete the csv now that we're done with it
        if ((Split-Path $scriptPath -Qualifier) -ne "S:") {
            Remove-Item -Path $lookupFilePath -Force
        }
        
        # Build target pwd
        $CustomBit = $serialNumber.Substring(1, 2)
        $NewValue = $Prepend + $CustomBit + $Postpend
        if ($TestMode) { Write-Log "Target is $NewValue" -Component "PwdReset" }

        # Define path to Dell BIOS management script
        $dellScriptPath = Join-Path $scriptPath "Manage-DellBiosPasswords-WMI.ps1"
		$dellLogPath = Join-Path -Path $logDir -ChildPath "Manage-DellBiosPasswords-WMI.log"

        # Verify Dell script exists
        if (-not (Test-Path $dellScriptPath)) {
            Write-Log "Dell BIOS management script not found: $dellScriptPath" -Type "ERROR" -Component "PwdReset"
            throw "Dell BIOS management script not found: $dellScriptPath"
        }

        # Execute Dell BIOS management script
        Write-Log "Executing Dell BIOS Password management script..." -Component "PwdReset"
        
		if ($null -ne $matchingEntry) { # Found an old pwd to try
		    if ($TestMode) {
				Write-Log "Try old: $dellScriptPath -AdminSet -AdminPassword $NewValue -OldAdminPassword $CurrentPwd -NoUserPrompt" -Component "PwdReset"
            }
            else {
				Write-Log "Try old: $dellScriptPath -AdminSet -AdminPassword NewValue -OldAdminPassword CurrentPwd -NoUserPrompt" -Component "PwdReset"
            }
            $result = & $dellScriptPath -AdminSet -AdminPassword $NewValue -OldAdminPassword $CurrentPwd -NoUserPrompt -LogFile $dellLogPath
			if ($LASTEXITCODE -eq 0) { # Old pwd was correct and has now been changed
				Write-Log "Old password was correct and has now been changed, or new was already correct" -Component "PwdReset"
				$resetSuccess = $true
			}
			else {
				$errCode = $LASTEXITCODE
			}
		}

		if (!$resetSuccess) { # Maybe it's blank
            if ($TestMode) {
				Write-Log "Try blank: $dellScriptPath -AdminSet -AdminPassword $NewValue -NoUserPrompt" -Component "PwdReset"
            }
            else {
				Write-Log "Try blank: $dellScriptPath -AdminSet -AdminPassword NewValue -NoUserPrompt" -Component "PwdReset"
            }
            $result = & $dellScriptPath -AdminSet -AdminPassword $NewValue -NoUserPrompt -LogFile $dellLogPath
			if ($LASTEXITCODE -eq 0) { # Blank pwd was correct and has now been set
				Write-Log "Password was blank and has now been set" -Component "PwdReset"
				$resetSuccess = $true
			}
			else {
				$errCode = $LASTEXITCODE
			}
        }

		if (!$resetSuccess) { # Maybe it's already fixed
            if ($TestMode) {
				Write-Log "Try fixed: $dellScriptPath -AdminSet -AdminPassword $NewValue -OldAdminPassword $NewValue -NoUserPrompt" -Component "PwdReset"
            }
            else {
 				Write-Log "Try fixed: $dellScriptPath -AdminSet -AdminPassword NewValue -OldAdminPassword NewValue -NoUserPrompt" -Component "PwdReset"
            }
            $result = & $dellScriptPath -AdminSet -AdminPassword $NewValue -OldAdminPassword $NewValue -NoUserPrompt -LogFile $dellLogPath
 			if ($LASTEXITCODE -eq 0) { # Password was already correct
				Write-Log "Password was already correct" -Component "PwdReset"
				$resetSuccess = $true
			}
			else {
				$errCode = $LASTEXITCODE
			}
		}
       
        # Log the result of the Dell script execution
        if ($resetSuccess) {
            Write-Log "Password update process completed successfully" -Component "PwdReset"
            Set-ItemProperty -Path $registryPath -Name "BIOSAP" -Value "$GroupTag Success"
        }
        else {
            Write-Log "Dell BIOS password script failed with exit code: $errCode" -Type "ERROR" -Component "PwdReset"
            Write-Log "Dell script output: $result" -Type "ERROR" -Component "PwdReset"
            Set-ItemProperty -Path $registryPath -Name "BIOSAP" -Value "$GroupTag Failure"
            throw "Dell BIOS password script failed"
			}
	}
    catch {
        Write-Log "Error occurred: $_" -Type "ERROR" -Component "PwdReset"
        Write-Log "Stack Trace: $($_.ScriptStackTrace)" -Type "ERROR" -Component "PwdReset"
    }
    finally {
        Write-Log "Password section finished" -Component "PwdReset"
        Write-Log "----------------------------------------" -Component "PwdReset"
    }
}
catch {
    Write-Log "Error in password reset step: $_" -Type "ERROR"
    exit 1
}

# Step 2: Apply standard BIOS settings
Write-Log "Step 2: Applying standard BIOS settings"

try {
    Write-Log "Running BIOS settings configuration"
    $settingsResult = Set-BiosSettings -AdminPassword $NewValue	-ScriptPath $scriptPath
    
    if ($settingsResult -eq 0) {
        Write-Log "Standard BIOS settings successfully applied"
    } 
    else {
        Write-Log "Check for BIOS setting errors" -Type "WARN"
    }
}
catch {
    Write-Log "Error in BIOS settings configuration: $_" -Type "ERROR"
	exit 2
}

Write-Log "Combined Dell BIOS configuration process completed"
exit 0
#endregion